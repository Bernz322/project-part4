export { default as Button } from './Button/Button';
export { default as Navbar } from './Navbar/Navbar';
export { default as Table } from './Table/Table';
export { default as DeleteModal } from './Modals/DeleteModal';
export { default as AddUploadModal } from './Modals/AddUploadModal';
export { default as EditUploadModal } from './Modals/EditUploadModal';